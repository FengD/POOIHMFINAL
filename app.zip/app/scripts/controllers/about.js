'use strict';

angular.module('pooIhmExemplesApp')
    .controller('FactoryCtrl', ['$scope', 'User', function($scope, User){
        User.all(function(user){
            $scope.users = user;
        });

        $scope.delete = function(user){
            if(user.id !== ''){
                User.delete(user.id);
                $scope.$apply();
            }
        };

        $scope.post = function(data){
            User.post(data);
        };

        $scope.put = function(user){
            User.put(user.id, user);
        };
}]);