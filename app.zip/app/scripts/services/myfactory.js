'use strict';

angular.module('pooIhmExemplesApp')
	.factory('User', ['$http', function($http){
		var obj = {
			get: function(userId){
				$http.get('http://poo-ihm-2015-rest.herokuapp.com/api/Users/' + userId)
					.success()
					.error();
				},

			delete: function(userId){
				$http.delete('http://poo-ihm-2015-rest.herokuapp.com/api/Users/' + userId)
					.success(function(){
						alert('delete success');
					})
					.error(function(){
						alert('delete error');
					}); 
				},

			put: function(userId, data){
				$http.put('http://poo-ihm-2015-rest.herokuapp.com/api/Users/' + userId, data)
					.success(function(){
						alert('put success');
					})
					.error(function(){
						alert('put error');
					}); 
				},

			post: function(data){
				$http.post('http://poo-ihm-2015-rest.herokuapp.com/api/Users', data)
					.success(function(){
						alert('post success');
					})
					.error(function(){
						alert('post error');
					}); 
				},

			all: function(successCB, fallCB){
				$http.get('http://poo-ihm-2015-rest.herokuapp.com/api/Users/')
					.success(function(Result){
						if(Result.status === 'success') {
         						var users = Result.data;
							successCB(users);
        					}
					})
					.error(function(error){
						fallCB(error);
					});
				}			
		};
		return obj;
}]);